# TamilZen (Android)

A ScreenZen-style focus app, written from scratch in Kotlin + Jetpack Compose.

## Build and install
1. Install Android Studio (Koala or newer).
2. File > Open > select this `TamilZen` folder. Let Gradle sync (accept any "use Gradle wrapper" prompt).
3. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s) and install the APK.
4. Open TamilZen > Home tab and follow the two setup cards:
   - Accessibility: turn TamilZen on. On Android 13+ for a sideloaded APK, first open
     Settings > Apps > TamilZen > ⋮ > "Allow restricted settings".
   - Usage access: allow TamilZen.

## Features
- Pause before opening: 0-60 s countdown, optional wait that grows +5 s on every open, breathing circle, custom message.
- Interrupt scrolling: timed sessions (1-30 min) followed by a cooldown.
- Goals: daily time limit and daily opens limit, each with optional hard block.
- Schedule: choose days and an active time window per app.
- Strict block: always, or inside a time window (can cross midnight).
- Focus timer: 15/30/60/120 min, blocks every app on your list.
- Word blocking: look for a word in the URL bar, in browser pages, or in any app; whole-word matching; forever or on a timer.
- Website blocking: block a domain forever or on a timer.
- Settings lock: PIN needed to open TamilZen.
- Streaks: a day counts if you never override a block or pass a goal.
- Emergency override: 5 more minutes, then the block returns; costs the day's streak.
- No INTERNET permission: nothing leaves the phone.

## Files (app/src/main/java/com/tamilzen/app)
- Models.kt: AppRule, KeywordRule, SiteRule, time helpers
- Store.kt: saved rules, counters, PIN, streak, focus timer
- Engine.kt: usage stats + the rules that decide delay / block / allow
- BlockerService.kt: accessibility service (detects app, runs timers, scans for words and sites)
- InterceptActivity.kt: the pause and block screens
- Ui.kt, MainActivity.kt, Theme.kt: the app screens

## Known limits
- Android only. iOS can't do this without Apple's Family Controls entitlement.
- Not compiled or tested yet. Expect to fix a few small errors on first build.
- Address bars are read for the browsers listed in `Browsers` (BlockerService.kt); add other browsers there.
- Hiding blocked apps from the home screen is not implemented (needs a launcher).
- Google Play restricts accessibility apps; fine for personal sideloading.

## Build the APK without Android Studio
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repo's Actions tab > "Build APK" > Run workflow.
3. When it finishes, download `TamilZen-debug-apk` from the run page and unzip it to get `app-debug.apk`.
