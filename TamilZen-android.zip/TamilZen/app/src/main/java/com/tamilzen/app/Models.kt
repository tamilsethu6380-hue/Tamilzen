package com.tamilzen.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Where a blocked word is looked for. */
enum class Scope(val label: String) {
    URL("URL / search bar"),
    PAGE("Browser page"),
    ALL_APPS("Any app")
}

/** Everything TamilZen does to one app. Days use Calendar.SUNDAY..SATURDAY = 1..7. */
data class AppRule(
    val pkg: String,
    val label: String,
    val enabled: Boolean = true,

    // Pause before opening
    val delaySeconds: Int = 10,
    val progressiveDelay: Boolean = false,
    val breathing: Boolean = true,
    val message: String = "Is this important?",

    // Interrupt scrolling: timed session, then cooldown
    val sessionMinutes: Int = 0,
    val cooldownMinutes: Int = 15,

    // Goals
    val dailyLimitMinutes: Int = 0,
    val blockAtLimit: Boolean = false,
    val dailyOpensLimit: Int = 0,
    val blockAtOpensLimit: Boolean = false,

    // Schedule: rule only applies on these days, inside this window (minutes since midnight)
    val days: Set<Int> = ALL_DAYS,
    val activeFromMin: Int = 0,
    val activeToMin: Int = 1440,

    // Strict block (ignores schedule)
    val strictAlways: Boolean = false,
    val strictFromMin: Int = -1, // -1 = no strict window
    val strictToMin: Int = -1,

    val allowEmergency: Boolean = true
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("pkg", pkg)
        put("label", label)
        put("enabled", enabled)
        put("delaySeconds", delaySeconds)
        put("progressiveDelay", progressiveDelay)
        put("breathing", breathing)
        put("message", message)
        put("sessionMinutes", sessionMinutes)
        put("cooldownMinutes", cooldownMinutes)
        put("dailyLimitMinutes", dailyLimitMinutes)
        put("blockAtLimit", blockAtLimit)
        put("dailyOpensLimit", dailyOpensLimit)
        put("blockAtOpensLimit", blockAtOpensLimit)
        put("days", JSONArray(days.toList()))
        put("activeFromMin", activeFromMin)
        put("activeToMin", activeToMin)
        put("strictAlways", strictAlways)
        put("strictFromMin", strictFromMin)
        put("strictToMin", strictToMin)
        put("allowEmergency", allowEmergency)
    }

    fun summary(): String {
        val parts = mutableListOf<String>()
        if (strictAlways) parts.add("strict block")
        if (strictFromMin >= 0) parts.add("blocked ${TimeUtil.fmt(strictFromMin)}-${TimeUtil.fmt(strictToMin)}")
        if (delaySeconds > 0) parts.add("${delaySeconds}s pause")
        if (sessionMinutes > 0) parts.add("${sessionMinutes}m sessions")
        if (dailyLimitMinutes > 0) parts.add("${dailyLimitMinutes}m/day")
        if (dailyOpensLimit > 0) parts.add("$dailyOpensLimit opens/day")
        return if (parts.isEmpty()) "No limits set" else parts.joinToString(" · ")
    }

    companion object {
        val ALL_DAYS: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7)

        fun fromJson(o: JSONObject): AppRule {
            val arr = o.optJSONArray("days")
            val days = if (arr == null) ALL_DAYS else (0 until arr.length()).map { arr.getInt(it) }.toSet()
            return AppRule(
                pkg = o.getString("pkg"),
                label = o.optString("label", o.getString("pkg")),
                enabled = o.optBoolean("enabled", true),
                delaySeconds = o.optInt("delaySeconds", 10),
                progressiveDelay = o.optBoolean("progressiveDelay", false),
                breathing = o.optBoolean("breathing", true),
                message = o.optString("message", "Is this important?"),
                sessionMinutes = o.optInt("sessionMinutes", 0),
                cooldownMinutes = o.optInt("cooldownMinutes", 15),
                dailyLimitMinutes = o.optInt("dailyLimitMinutes", 0),
                blockAtLimit = o.optBoolean("blockAtLimit", false),
                dailyOpensLimit = o.optInt("dailyOpensLimit", 0),
                blockAtOpensLimit = o.optBoolean("blockAtOpensLimit", false),
                days = days,
                activeFromMin = o.optInt("activeFromMin", 0),
                activeToMin = o.optInt("activeToMin", 1440),
                strictAlways = o.optBoolean("strictAlways", false),
                strictFromMin = o.optInt("strictFromMin", -1),
                strictToMin = o.optInt("strictToMin", -1),
                allowEmergency = o.optBoolean("allowEmergency", true)
            )
        }
    }
}

/** A blocked word. untilMillis == 0 means "forever", otherwise it is a timer that expires. */
data class KeywordRule(
    val word: String,
    val scope: Scope = Scope.PAGE,
    val wholeWord: Boolean = true,
    val untilMillis: Long = 0L
) {
    fun isActive(now: Long): Boolean = untilMillis == 0L || now < untilMillis

    private val regex: Regex by lazy {
        val core = Regex.escape(word.trim())
        val pattern = if (wholeWord) "(?<![\\p{L}\\p{N}])$core(?![\\p{L}\\p{N}])" else core
        Regex(pattern, RegexOption.IGNORE_CASE)
    }

    fun matches(text: String): Boolean = word.isNotBlank() && regex.containsMatchIn(text)
}

/** A blocked website (domain). untilMillis works like KeywordRule. */
data class SiteRule(val domain: String, val untilMillis: Long = 0L) {
    fun isActive(now: Long): Boolean = untilMillis == 0L || now < untilMillis

    companion object {
        fun normalize(input: String): String = input.trim().lowercase()
            .removePrefix("https://")
            .removePrefix("http://")
            .removePrefix("www.")
            .substringBefore('/')
            .substringBefore('?')
    }
}

object TimeUtil {
    fun nowMinutes(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    fun today(): Int = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)

    /** [from, to) in minutes since midnight; handles windows that cross midnight. */
    fun inWindow(now: Int, from: Int, to: Int): Boolean =
        if (from <= to) now in from until to else now >= from || now < to

    fun fmt(min: Int): String =
        if (min >= 1440) "24:00" else "%02d:%02d".format(min / 60, min % 60)
}
