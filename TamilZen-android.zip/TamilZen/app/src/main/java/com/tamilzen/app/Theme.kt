package com.tamilzen.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF111315)
val Panel = Color(0xFF1A1D1F)
val PanelHi = Color(0xFF24282A)
val Ivory = Color(0xFFF4F1E8)
val Muted = Color(0xFFA8AEAB)
val Sage = Color(0xFFA8C2B0)
val Amber = Color(0xFFE3B84F)

@Composable
fun TamilZenTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Sage,
            onPrimary = Bg,
            secondary = Amber,
            onSecondary = Bg,
            background = Bg,
            onBackground = Ivory,
            surface = Panel,
            onSurface = Ivory,
            surfaceVariant = PanelHi,
            onSurfaceVariant = Muted,
            outline = Color(0xFF3A403F)
        ),
        content = content
    )
}
