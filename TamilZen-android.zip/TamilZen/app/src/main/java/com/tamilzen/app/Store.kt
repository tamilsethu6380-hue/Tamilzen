package com.tamilzen.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Store private constructor(ctx: Context) {

    private val p: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("tamilzen", Context.MODE_PRIVATE)

    @Volatile private var rulesCache: List<AppRule>? = null
    @Volatile private var kwCache: List<KeywordRule>? = null
    @Volatile private var siteCache: List<SiteRule>? = null

    companion object {
        @Volatile private var inst: Store? = null
        fun get(ctx: Context): Store =
            inst ?: synchronized(this) { inst ?: Store(ctx).also { inst = it } }
    }

    // ---------- App rules ----------

    fun rules(): List<AppRule> = rulesCache ?: runCatching {
        val a = JSONArray(p.getString("rules", "[]"))
        (0 until a.length()).map { AppRule.fromJson(a.getJSONObject(it)) }
    }.getOrDefault(emptyList()).also { rulesCache = it }

    fun rule(pkg: String): AppRule? = rules().firstOrNull { it.pkg == pkg }

    fun saveRules(list: List<AppRule>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        p.edit().putString("rules", a.toString()).apply()
        rulesCache = list
    }

    fun upsert(r: AppRule) = saveRules(rules().filter { it.pkg != r.pkg } + r)
    fun remove(pkg: String) = saveRules(rules().filter { it.pkg != pkg })

    // ---------- Blocked words & sites ----------

    fun keywords(): List<KeywordRule> = kwCache ?: runCatching {
        val a = JSONArray(p.getString("kw", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            KeywordRule(
                word = o.getString("word"),
                scope = runCatching { Scope.valueOf(o.optString("scope", "PAGE")) }.getOrDefault(Scope.PAGE),
                wholeWord = o.optBoolean("whole", true),
                untilMillis = o.optLong("until", 0L)
            )
        }
    }.getOrDefault(emptyList()).also { kwCache = it }

    fun saveKeywords(list: List<KeywordRule>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("word", it.word).put("scope", it.scope.name)
                .put("whole", it.wholeWord).put("until", it.untilMillis))
        }
        p.edit().putString("kw", a.toString()).apply()
        kwCache = list
    }

    fun sites(): List<SiteRule> = siteCache ?: runCatching {
        val a = JSONArray(p.getString("sites", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            SiteRule(o.getString("domain"), o.optLong("until", 0L))
        }
    }.getOrDefault(emptyList()).also { siteCache = it }

    fun saveSites(list: List<SiteRule>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("domain", it.domain).put("until", it.untilMillis)) }
        p.edit().putString("sites", a.toString()).apply()
        siteCache = list
    }

    // ---------- PIN (locks the TamilZen settings screens) ----------

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest("tz:$pin".toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin(): Boolean = !p.getString("pin", null).isNullOrEmpty()
    fun setPin(pin: String?) {
        if (pin.isNullOrEmpty()) p.edit().remove("pin").apply()
        else p.edit().putString("pin", hash(pin)).apply()
    }
    fun checkPin(pin: String): Boolean = p.getString("pin", null) == hash(pin)

    // ---------- Focus timer ----------

    var focusUntil: Long
        get() = p.getLong("focusUntil", 0L)
        set(v) { p.edit().putLong("focusUntil", v).apply() }

    // ---------- Daily counters ----------

    fun dayKey(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun opensToday(pkg: String): Int = p.getInt("opens_${dayKey()}_$pkg", 0)
    fun addOpen(pkg: String) {
        p.edit().putInt("opens_${dayKey()}_$pkg", opensToday(pkg) + 1).apply()
    }

    fun cooldownUntil(pkg: String): Long = p.getLong("cd_$pkg", 0L)
    fun setCooldown(pkg: String, until: Long) {
        p.edit().putLong("cd_$pkg", until).apply()
    }

    // ---------- Streak ----------
    // A day counts if you never overrode a block and never went past a goal.

    fun streak(): Int = p.getInt("streak", 0)

    fun refreshStreak() {
        val today = dayKey()
        val last = p.getString("streakDay", null)
        if (last == today) return
        val e = p.edit()
        if (last != null) {
            val broke = p.getString("brokeDay", null) == last
            e.putInt("streak", if (broke) 0 else p.getInt("streak", 0) + 1)
            p.all.keys
                .filter { it.startsWith("opens_") && !it.startsWith("opens_$today") }
                .forEach { e.remove(it) }
        }
        e.putString("streakDay", today)
        e.apply()
    }

    fun markBroken() {
        p.edit().putString("brokeDay", dayKey()).apply()
    }

    fun brokenToday(): Boolean = p.getString("brokeDay", null) == dayKey()

    fun resetStreak() {
        p.edit().putInt("streak", 0).apply()
    }
}
