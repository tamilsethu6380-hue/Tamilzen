package com.tamilzen.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class InterceptActivity : ComponentActivity() {

    private var decided = false
    private lateinit var store: Store

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store.get(this)
        SessionState.interceptShowing = true
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })
        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        decided = false
        render()
    }

    private fun render() {
        val pkg = intent.getStringExtra("pkg")
        if (pkg == null) {
            finish()
            return
        }
        val mode = intent.getStringExtra("mode") ?: "delay"

        if (mode == "block") {
            val title = intent.getStringExtra("title") ?: "Blocked"
            val detail = intent.getStringExtra("detail") ?: ""
            val canOverride = intent.getBooleanExtra("canOverride", false)
            setContent {
                TamilZenTheme {
                    BlockScreen(
                        title = title,
                        detail = detail,
                        canOverride = canOverride,
                        onHome = { goHome() },
                        onEmergency = { emergency(pkg) }
                    )
                }
            }
        } else {
            val rule = store.rule(pkg)
            if (rule == null) {
                finish()
                return
            }
            val seconds = intent.getIntExtra("seconds", rule.delaySeconds)
            val streak = store.streak()
            val opens = store.opensToday(pkg)
            setContent {
                TamilZenTheme {
                    DelayScreen(
                        label = rule.label,
                        message = rule.message,
                        seconds = seconds,
                        breathing = rule.breathing,
                        streak = streak,
                        opensToday = opens,
                        sessionMinutes = rule.sessionMinutes,
                        onClose = { goHome() },
                        onContinue = { approve(rule) }
                    )
                }
            }
        }
    }

    private fun goHome() {
        decided = true
        SessionState.activePkg = null
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    private fun approve(rule: AppRule) {
        decided = true
        store.addOpen(rule.pkg)
        SessionState.activePkg = rule.pkg
        SessionState.sessionEndsAt =
            if (rule.sessionMinutes > 0) System.currentTimeMillis() + rule.sessionMinutes * 60_000L else 0L
        finish()
    }

    /** 5 more minutes. Costs you today's streak. When the 5 minutes end, the block comes back. */
    private fun emergency(pkg: String) {
        decided = true
        store.markBroken()
        store.setCooldown(pkg, 0L)
        val until = System.currentTimeMillis() + 5 * 60_000L
        SessionState.overrideUntil[pkg] = until
        SessionState.activePkg = pkg
        SessionState.sessionEndsAt = until
        finish()
    }

    override fun onStop() {
        super.onStop()
        if (!decided && !isChangingConfigurations) {
            // Left via Home / Recents without choosing: treat as leaving the app.
            SessionState.activePkg = null
            finish()
        }
    }

    override fun onDestroy() {
        SessionState.interceptShowing = false
        super.onDestroy()
    }
}

@Composable
private fun DelayScreen(
    label: String,
    message: String,
    seconds: Int,
    breathing: Boolean,
    streak: Int,
    opensToday: Int,
    sessionMinutes: Int,
    onClose: () -> Unit,
    onContinue: () -> Unit
) {
    var left by remember { mutableIntStateOf(seconds) }
    LaunchedEffect(Unit) {
        while (left > 0) {
            delay(1000)
            left--
        }
    }

    var inhale by remember { mutableStateOf(true) }
    LaunchedEffect(breathing) {
        if (breathing) {
            while (true) {
                delay(4000)
                inhale = !inhale
            }
        }
    }
    val scale by animateFloatAsState(
        targetValue = if (breathing && !inhale) 0.72f else 1f,
        animationSpec = tween(4000, easing = FastOutSlowInEasing),
        label = "breath"
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("PAUSE", fontSize = 12.sp, letterSpacing = 3.sp, color = Amber)
        Spacer12()
        Text(label, fontFamily = FontFamily.Serif, fontSize = 40.sp, color = Ivory)
        Spacer12()
        Text(message, fontSize = 18.sp, color = Muted)
        Spacer(40)

        Box(Modifier.size(200.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(200.dp)
                    .scale(scale)
                    .clip(CircleShape)
                    .background(Sage.copy(alpha = 0.22f))
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (left > 0) "$left" else "·",
                    fontFamily = FontFamily.Serif,
                    fontSize = 56.sp,
                    color = Ivory
                )
                if (breathing) {
                    Text(if (inhale) "breathe in" else "breathe out", fontSize = 13.sp, color = Muted)
                }
            }
        }

        Spacer(40)
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) {
            Text("Close $label")
        }
        Spacer(8)
        OutlinedButton(onClick = onContinue, enabled = left == 0, modifier = Modifier.fillMaxWidth()) {
            Text(
                when {
                    left > 0 -> "Continue in ${left}s"
                    sessionMinutes > 0 -> "Continue for $sessionMinutes min"
                    else -> "Continue"
                }
            )
        }
        Spacer(24)
        Text(
            "Streak: $streak day${if (streak == 1) "" else "s"}  ·  Opened $opensToday× today",
            fontSize = 13.sp,
            color = Muted
        )
    }
}

@Composable
private fun BlockScreen(
    title: String,
    detail: String,
    canOverride: Boolean,
    onHome: () -> Unit,
    onEmergency: () -> Unit
) {
    var wait by remember { mutableIntStateOf(10) }
    LaunchedEffect(Unit) {
        while (wait > 0) {
            delay(1000)
            wait--
        }
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .padding(32.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("BLOCKED", fontSize = 12.sp, letterSpacing = 3.sp, color = Amber)
        Spacer12()
        Text(title, fontFamily = FontFamily.Serif, fontSize = 44.sp, lineHeight = 48.sp, color = Ivory)
        Spacer12()
        Text(detail, fontSize = 17.sp, color = Muted)
        Spacer(40)
        Button(onClick = onHome, modifier = Modifier.fillMaxWidth()) { Text("Go home") }
        if (canOverride) {
            TextButton(onClick = onEmergency, enabled = wait == 0, modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (wait > 0) "Emergency access in ${wait}s"
                    else "Emergency: 5 more minutes (breaks streak)"
                )
            }
        }
    }
}

@Composable
private fun Spacer(h: Int) = androidx.compose.foundation.layout.Spacer(Modifier.height(h.dp))

@Composable
private fun Spacer12() = Spacer(12)
