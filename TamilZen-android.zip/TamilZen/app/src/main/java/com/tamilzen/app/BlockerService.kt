package com.tamilzen.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager

/** Browsers whose address bar we know how to read (package -> view id of the URL bar). */
object Browsers {
    val urlBarIds = mapOf(
        "com.android.chrome" to "com.android.chrome:id/url_bar",
        "com.chrome.beta" to "com.chrome.beta:id/url_bar",
        "com.sec.android.app.sbrowser" to "com.sec.android.app.sbrowser:id/location_bar_edit_text",
        "org.mozilla.firefox" to "org.mozilla.firefox:id/mozac_browser_toolbar_url_view",
        "com.brave.browser" to "com.brave.browser:id/url_bar",
        "com.microsoft.emmx" to "com.microsoft.emmx:id/url_bar",
        "com.opera.browser" to "com.opera.browser:id/url_field",
        "com.vivaldi.browser" to "com.vivaldi.browser:id/url_bar",
        "com.duckduckgo.mobile.android" to "com.duckduckgo.mobile.android:id/omnibarTextInput"
    )
}

class BlockerService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: Store
    private var launchers: Set<String> = emptySet()
    private var imes: Set<String> = emptySet()
    private var lastScan = 0L
    private var ticks = 0

    private val ticker = object : Runnable {
        override fun run() {
            runCatching { tick() }
            handler.postDelayed(this, 5_000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        store = Store.get(this)
        refreshSets()
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 5_000L)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onInterrupt() {}

    private fun refreshSets() {
        launchers = packageManager
            .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .map { it.activityInfo.packageName }.toSet()
        imes = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.map { it.packageName }.toSet()
    }

    private fun isIgnored(pkg: String) =
        pkg == packageName || pkg == "com.android.systemui" || pkg in imes

    // ------------------------------------------------------------------ events

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString() ?: return
        if (isIgnored(pkg)) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) onForeground(pkg)
        scan(pkg)
    }

    /** An app other than TamilZen just came to the front. */
    private fun onForeground(pkg: String) {
        store.refreshStreak()
        if (pkg == SessionState.activePkg) return
        SessionState.activePkg = null // we left whatever session we were in
        if (pkg in launchers) return
        if (SessionState.interceptShowing && SessionState.lastLaunchPkg == pkg) return

        val rule = store.rule(pkg)?.takeIf { it.enabled } ?: return
        when (val d = Engine.decide(this, rule)) {
            is Decision.Allow -> SessionState.activePkg = pkg
            is Decision.Delay -> showDelay(rule, d.seconds)
            is Decision.Block -> showBlock(pkg, d)
        }
    }

    // ------------------------------------------------------------------ timer

    private fun tick() {
        ticks++
        if (ticks % 12 == 0) refreshSets()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return
        store.refreshStreak()

        // Safety net: a listed app is on screen but was never approved (e.g. the pause screen was dismissed).
        if (!SessionState.interceptShowing) {
            val cur = rootInActiveWindow?.packageName?.toString()
            if (cur != null && !isIgnored(cur) && cur != SessionState.activePkg) onForeground(cur)
        }

        val pkg = SessionState.activePkg ?: return
        val rule = store.rule(pkg)?.takeIf { it.enabled } ?: return
        val now = System.currentTimeMillis()

        // Interrupt-scrolling session ran out
        val end = SessionState.sessionEndsAt
        if (end > 0L && now >= end) {
            SessionState.sessionEndsAt = 0L
            SessionState.activePkg = null
            store.setCooldown(pkg, now + rule.cooldownMinutes * 60_000L)
            showBlock(
                pkg,
                Decision.Block(
                    "Time's up",
                    "Take a break. ${rule.label} unlocks in ${rule.cooldownMinutes} min.",
                    rule.allowEmergency
                )
            )
            return
        }

        // Focus timer started, strict window began, daily limit hit...
        val hb = Engine.hardBlock(this, rule)
        if (hb != null) {
            SessionState.activePkg = null
            showBlock(pkg, hb)
            return
        }
        Engine.checkSoftLimits(this, rule)
    }

    // ------------------------------------------------------------------ pause / block screens

    private fun showDelay(rule: AppRule, seconds: Int) = launch(
        Intent(this, InterceptActivity::class.java)
            .putExtra("mode", "delay")
            .putExtra("pkg", rule.pkg)
            .putExtra("seconds", seconds)
    )

    private fun showBlock(pkg: String, b: Decision.Block) = launch(
        Intent(this, InterceptActivity::class.java)
            .putExtra("mode", "block")
            .putExtra("pkg", pkg)
            .putExtra("title", b.title)
            .putExtra("detail", b.detail)
            .putExtra("canOverride", b.canOverride)
    )

    private fun launch(i: Intent) {
        val pkg = i.getStringExtra("pkg")
        val t = SystemClock.uptimeMillis()
        if (SessionState.lastLaunchPkg == pkg && t - SessionState.lastLaunchAt < 1_500L) return
        SessionState.lastLaunchPkg = pkg
        SessionState.lastLaunchAt = t
        i.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_NO_ANIMATION
        )
        startActivity(i)
    }

    // ------------------------------------------------------------------ word & website blocking

    private fun scan(pkg: String) {
        if (pkg in launchers) return
        val now = System.currentTimeMillis()
        val kws = store.keywords().filter { it.isActive(now) }
        val sites = store.sites().filter { it.isActive(now) }
        if (kws.isEmpty() && sites.isEmpty()) return

        val isBrowser = pkg in Browsers.urlBarIds
        val needAllApps = kws.any { it.scope == Scope.ALL_APPS }
        if (!isBrowser && !needAllApps) return

        val t = SystemClock.uptimeMillis()
        if (t - lastScan < 800L) return
        lastScan = t

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return

        val url = if (isBrowser) readUrl(root, pkg) else null
        if (url != null) {
            val lc = url.lowercase()
            val site = sites.firstOrNull { lc.contains(it.domain) }
            if (site != null) {
                hit(pkg, "Blocked site", "${site.domain} is on your block list.")
                return
            }
        }

        var page: String? = null
        fun pageText(): String {
            page?.let { return it }
            val sb = StringBuilder()
            collect(root, sb, intArrayOf(600))
            return sb.toString().also { page = it }
        }

        for (k in kws) {
            val hay: String? = when (k.scope) {
                Scope.URL -> url
                Scope.PAGE -> if (isBrowser) url.orEmpty() + "\n" + pageText() else null
                Scope.ALL_APPS -> pageText()
            }
            if (hay != null && k.matches(hay)) {
                hit(pkg, "Blocked word", "\"${k.word}\" is on your block list.")
                return
            }
        }
    }

    private fun hit(pkg: String, title: String, detail: String) {
        SessionState.activePkg = null
        showBlock(pkg, Decision.Block(title, detail, false))
    }

    private fun readUrl(root: AccessibilityNodeInfo, pkg: String): String? {
        val id = Browsers.urlBarIds[pkg]
        if (id != null) {
            val node = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()
            val text = node?.text?.toString()
            if (!text.isNullOrBlank()) return text
        }
        return findEditText(root, 0) // fallback for browser versions that renamed the view id
    }

    private fun findEditText(node: AccessibilityNodeInfo?, depth: Int): String? {
        if (node == null || depth > 12) return null
        if (node.className?.toString() == "android.widget.EditText") {
            val t = node.text?.toString()
            if (!t.isNullOrBlank()) return t
        }
        for (i in 0 until node.childCount) {
            findEditText(node.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }

    private fun collect(node: AccessibilityNodeInfo?, sb: StringBuilder, budget: IntArray) {
        if (node == null || budget[0] <= 0) return
        budget[0]--
        node.text?.let { sb.append(it).append('\n') }
        node.contentDescription?.let { sb.append(it).append('\n') }
        for (i in 0 until node.childCount) collect(node.getChild(i), sb, budget)
    }
}
