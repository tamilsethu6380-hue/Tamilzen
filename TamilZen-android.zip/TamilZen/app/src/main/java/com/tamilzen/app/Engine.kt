package com.tamilzen.app

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap

/** In-memory state shared by the accessibility service and the pause screen (same process). */
object SessionState {
    @Volatile var activePkg: String? = null        // app the user has been let into
    @Volatile var sessionEndsAt: Long = 0L         // 0 = untimed session
    @Volatile var interceptShowing = false
    @Volatile var lastLaunchPkg: String? = null
    @Volatile var lastLaunchAt = 0L
    val overrideUntil = ConcurrentHashMap<String, Long>()
}

object Usage {
    private var cache: Map<String, Long> = emptyMap()
    private var cacheAt = 0L

    @Suppress("DEPRECATION")
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun startOfDay(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    /** Foreground milliseconds per package since midnight. */
    @Synchronized
    @Suppress("DEPRECATION")
    fun todayMs(ctx: Context, maxAgeMs: Long = 8_000L): Map<String, Long> {
        val now = System.currentTimeMillis()
        if (now - cacheAt < maxAgeMs) return cache
        if (!hasAccess(ctx)) return emptyMap()
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(startOfDay(), now)
        val ev = UsageEvents.Event()
        val resumedAt = HashMap<String, Long>()
        val total = HashMap<String, Long>()
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            val pkg = ev.packageName ?: continue
            when (ev.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> resumedAt[pkg] = ev.timeStamp
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    val start = resumedAt.remove(pkg)
                    if (start != null) total[pkg] = (total[pkg] ?: 0L) + (ev.timeStamp - start)
                }
            }
        }
        resumedAt.forEach { (pkg, start) -> total[pkg] = (total[pkg] ?: 0L) + (now - start) }
        cache = total
        cacheAt = now
        return total
    }
}

sealed class Decision {
    object Allow : Decision()
    data class Delay(val seconds: Int) : Decision()
    data class Block(val title: String, val detail: String, val canOverride: Boolean) : Decision()
}

object Engine {

    fun isScheduled(r: AppRule): Boolean =
        TimeUtil.today() in r.days &&
            TimeUtil.inWindow(TimeUtil.nowMinutes(), r.activeFromMin, r.activeToMin)

    private fun overridden(r: AppRule): Boolean =
        (SessionState.overrideUntil[r.pkg] ?: 0L) > System.currentTimeMillis()

    /** Blocks that apply both when opening an app and while using it. */
    fun hardBlock(ctx: Context, r: AppRule): Decision.Block? {
        val store = Store.get(ctx)
        val now = System.currentTimeMillis()

        // Focus timer: every app on your list is blocked
        if (store.focusUntil > now) {
            val mins = ((store.focusUntil - now) / 60_000L).toInt() + 1
            return Decision.Block("Focus session", "${r.label} is blocked for $mins more min.", false)
        }

        // Strict blocks ignore the schedule
        if (r.strictAlways) {
            return Decision.Block("Blocked", "${r.label} is strictly blocked.", false)
        }
        if (r.strictFromMin >= 0 && r.strictToMin >= 0 &&
            TimeUtil.inWindow(TimeUtil.nowMinutes(), r.strictFromMin, r.strictToMin)
        ) {
            return Decision.Block(
                "Blocked until ${TimeUtil.fmt(r.strictToMin)}",
                "${r.label} is blocked from ${TimeUtil.fmt(r.strictFromMin)} to ${TimeUtil.fmt(r.strictToMin)}.",
                false
            )
        }

        if (!overridden(r) && isScheduled(r)) {
            val cd = store.cooldownUntil(r.pkg)
            if (cd > now) {
                val mins = ((cd - now) / 60_000L).toInt() + 1
                return Decision.Block("Cooling down", "${r.label} unlocks in $mins min.", r.allowEmergency)
            }
            if (r.dailyLimitMinutes > 0 && r.blockAtLimit) {
                val used = Usage.todayMs(ctx)[r.pkg] ?: 0L
                if (used >= r.dailyLimitMinutes * 60_000L) {
                    return Decision.Block(
                        "Daily limit reached",
                        "You've used your ${r.dailyLimitMinutes} min of ${r.label} today.",
                        r.allowEmergency
                    )
                }
            }
        }
        return null
    }

    /** What to do when the app comes to the foreground and no session is active. */
    fun decide(ctx: Context, r: AppRule): Decision {
        hardBlock(ctx, r)?.let { return it }
        if (!isScheduled(r)) return Decision.Allow

        val store = Store.get(ctx)
        val opens = store.opensToday(r.pkg)

        if (r.dailyOpensLimit > 0 && opens >= r.dailyOpensLimit) {
            if (r.blockAtOpensLimit && !overridden(r)) {
                return Decision.Block(
                    "No opens left",
                    "You've opened ${r.label} $opens times today.",
                    r.allowEmergency
                )
            }
            store.markBroken()
        }

        var secs = r.delaySeconds
        if (r.progressiveDelay) secs += opens * 5
        secs = minOf(secs, maxOf(r.delaySeconds, 120))

        return if (secs > 0 || r.sessionMinutes > 0) Decision.Delay(secs) else Decision.Allow
    }

    /** Goals that don't block still cost you your streak when you pass them. */
    fun checkSoftLimits(ctx: Context, r: AppRule) {
        if (r.dailyLimitMinutes > 0 && !r.blockAtLimit && isScheduled(r)) {
            val used = Usage.todayMs(ctx)[r.pkg] ?: 0L
            if (used >= r.dailyLimitMinutes * 60_000L) Store.get(ctx).markBroken()
        }
    }
}
