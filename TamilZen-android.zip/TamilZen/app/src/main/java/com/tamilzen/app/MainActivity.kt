package com.tamilzen.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {

    private val unlocked = mutableStateOf(false)
    private var refresh by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store.get(this)
        unlocked.value = !store.hasPin()
        setContent {
            TamilZenTheme {
                Root(store, unlocked.value, refresh) { unlocked.value = true }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Store.get(this).refreshStreak()
        refresh++
    }

    override fun onStop() {
        super.onStop()
        if (Store.get(this).hasPin()) unlocked.value = false
    }
}
