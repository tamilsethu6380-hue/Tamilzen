package com.tamilzen.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// ============================================================ helpers

fun isServiceEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val cn = ComponentName(ctx, BlockerService::class.java)
    return enabled.split(':').any {
        it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
    }
}

fun fmtDuration(ms: Long): String {
    val m = ms / 60_000L
    return when {
        m >= 60 -> "${m / 60}h ${"%02d".format(m % 60)}m"
        m >= 1 -> "${m}m"
        else -> "<1m"
    }
}

fun fmtClock(ms: Long): String {
    val s = ms / 1000L
    return "%d:%02d".format(s / 60, s % 60)
}

fun loadLaunchableApps(ctx: Context): List<Pair<String, String>> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
        .filter { it.first != ctx.packageName }
        .distinctBy { it.first }
        .sortedBy { it.second.lowercase() }
}

private val SUGGESTED_MESSAGES = listOf(
    "Is this important?",
    "What do you need right now?",
    "Will this matter tomorrow?",
    "Take a breath first.",
    "Is this how you want to spend your time?"
)

private val DURATIONS = listOf(
    "Forever" to 0L,
    "1 hour" to 3_600_000L,
    "4 hours" to 14_400_000L,
    "24 hours" to 86_400_000L,
    "7 days" to 604_800_000L
)

// ============================================================ small building blocks

@Composable
fun Title(text: String) {
    Text(text, fontFamily = FontFamily.Serif, fontSize = 40.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun SectionLabel(text: String) {
    Spacer(Modifier.height(24.dp))
    Text(
        text.uppercase(),
        fontSize = 12.sp,
        letterSpacing = 1.5.sp,
        color = Sage,
        fontWeight = FontWeight.SemiBold
    )
    Spacer(Modifier.height(6.dp))
}

@Composable
fun MutedText(text: String, size: Int = 14) {
    Text(text, fontSize = size.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    val shape = RoundedCornerShape(10.dp)
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size).clip(shape))
    } else {
        Box(Modifier.size(size).clip(shape).background(PanelHi))
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SliderRow(
    title: String,
    value: Int,
    min: Int,
    max: Int,
    step: Int = 1,
    fmt: (Int) -> String,
    onChange: (Int) -> Unit
) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title)
            Text(fmt(value), color = Sage)
        }
        val steps = ((max - min) / step - 1).coerceAtLeast(0)
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(((it - min) / step).roundToInt() * step + min) },
            valueRange = min.toFloat()..max.toFloat(),
            steps = steps
        )
    }
}

@Composable
fun ChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEachIndexed { i, label ->
            FilterChip(selected = selected == i, onClick = { onSelect(i) }, label = { Text(label) })
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            MutedText(title, 12)
            Spacer(Modifier.height(4.dp))
            Text(value, fontFamily = FontFamily.Serif, fontSize = 28.sp)
        }
    }
}

@Composable
fun SetupCard(title: String, body: String, button: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(top = 12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            MutedText(body)
            Spacer(Modifier.height(10.dp))
            Button(onClick = onClick) { Text(button) }
        }
    }
}

// ============================================================ root

@Composable
fun Root(store: Store, unlocked: Boolean, refresh: Int, onUnlock: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (!unlocked) {
            PinScreen(store, onUnlock)
        } else {
            var tab by remember { mutableIntStateOf(0) }
            var editing by remember { mutableStateOf<AppRule?>(null) }
            val e = editing
            if (e != null) {
                RuleEditor(
                    initial = e,
                    existing = store.rule(e.pkg) != null,
                    onSave = { store.upsert(it); editing = null },
                    onDelete = { store.remove(e.pkg); editing = null },
                    onBack = { editing = null }
                )
            } else {
                val tabs = listOf("Home", "Apps", "Words", "Settings")
                val glyphs = listOf("◐", "▦", "Aa", "⚙")
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = {
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                            tabs.forEachIndexed { i, t ->
                                NavigationBarItem(
                                    selected = tab == i,
                                    onClick = { tab = i },
                                    icon = { Text(glyphs[i]) },
                                    label = { Text(t) }
                                )
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad)) {
                        when (tab) {
                            0 -> HomeScreen(store, refresh)
                            1 -> AppsScreen(store) { editing = it }
                            2 -> WordsScreen(store)
                            else -> SettingsScreen(store)
                        }
                    }
                }
            }
        }
    }
}

// ============================================================ PIN

@Composable
fun PinScreen(store: Store, onUnlock: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center) {
        Title("TamilZen")
        Spacer(Modifier.height(8.dp))
        MutedText("Enter your PIN to change settings.")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { pin = it.filter(Char::isDigit).take(8); err = false },
            label = { Text("PIN") },
            singleLine = true,
            isError = err,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        if (err) Text("Wrong PIN", color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { if (store.checkPin(pin)) onUnlock() else err = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Unlock") }
    }
}

// ============================================================ home

@Composable
fun HomeScreen(store: Store, refresh: Int) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    val svcOn = remember(refresh) { isServiceEnabled(ctx) }
    val usageOn = remember(refresh) { Usage.hasAccess(ctx) }
    val streak = remember(refresh) { store.streak() }
    val usage = remember(refresh, now / 15_000L) { if (usageOn) Usage.todayMs(ctx, 0L) else emptyMap() }
    val rules = store.rules().filter { it.enabled }
    val totalMs = rules.sumOf { usage[it.pkg] ?: 0L }
    val focusLeft = store.focusUntil - now

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Title("TamilZen")
        MutedText("Take your time back.", 16)

        if (!svcOn) {
            SetupCard(
                "1. Turn on TamilZen in Accessibility",
                "TamilZen needs this to see which app or website is open so it can pause or block it. " +
                    "Nothing leaves your phone. On Android 13+, you may first need App info > ⋮ > Allow restricted settings.",
                "Open Accessibility settings"
            ) { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        if (!usageOn) {
            SetupCard(
                "2. Allow Usage access",
                "Lets TamilZen measure your daily time and opens per app.",
                "Open Usage access settings"
            ) { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }

        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Distracting time today", fmtDuration(totalMs), Modifier.weight(1f))
            StatCard("Streak", "$streak day${if (streak == 1) "" else "s"}", Modifier.weight(1f))
        }

        SectionLabel("Focus timer")
        if (focusLeft > 0) {
            Text(fmtClock(focusLeft), fontFamily = FontFamily.Serif, fontSize = 48.sp, color = Amber)
            MutedText("Every app on your list is blocked.")
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { store.focusUntil = 0L }) { Text("End focus") }
        } else {
            MutedText("Blocks every app on your list for a set time.")
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(15, 30, 60, 120).forEach { m ->
                    AssistChip(
                        onClick = { store.focusUntil = System.currentTimeMillis() + m * 60_000L },
                        label = { Text("$m min") }
                    )
                }
            }
        }

        SectionLabel("Today by app")
        if (rules.isEmpty()) {
            MutedText("Pick apps on the Apps tab to start.")
        } else {
            rules.sortedByDescending { usage[it.pkg] ?: 0L }.forEach { r ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(r.pkg, 36.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.label)
                        MutedText("${store.opensToday(r.pkg)} opens through TamilZen", 12)
                    }
                    Text(fmtDuration(usage[r.pkg] ?: 0L), color = Sage)
                }
            }
        }
    }
}

// ============================================================ apps

@Composable
fun AppsScreen(store: Store, onEdit: (AppRule) -> Unit) {
    val ctx = LocalContext.current
    val apps by produceState(initialValue = emptyList<Pair<String, String>>()) {
        value = withContext(Dispatchers.IO) { loadLaunchableApps(ctx) }
    }
    var query by remember { mutableStateOf("") }
    var version by remember { mutableIntStateOf(0) }
    val rules = remember(version) { store.rules().associateBy { it.pkg } }

    val shown = apps
        .filter { it.second.contains(query, ignoreCase = true) }
        .sortedWith(compareByDescending<Pair<String, String>> { rules[it.first]?.enabled == true }
            .thenBy { it.second.lowercase() })

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(24.dp))
        Title("Apps")
        MutedText("Switch on the apps that pull you in. Tap one to tune it.")
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search apps") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(shown, key = { it.first }) { (pkg, label) ->
                val rule = rules[pkg]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onEdit(rule ?: AppRule(pkg = pkg, label = label)) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(pkg)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(label)
                        if (rule != null) MutedText(rule.summary(), 12)
                    }
                    Switch(
                        checked = rule?.enabled == true,
                        onCheckedChange = { on ->
                            if (rule == null) store.upsert(AppRule(pkg = pkg, label = label))
                            else store.upsert(rule.copy(enabled = on))
                            version++
                        }
                    )
                }
            }
        }
    }
}

// ============================================================ rule editor

@Composable
fun RuleEditor(
    initial: AppRule,
    existing: Boolean,
    onSave: (AppRule) -> Unit,
    onDelete: () -> Unit,
    onBack: () -> Unit
) {
    var r by remember { mutableStateOf(initial) }
    BackHandler { onBack() }

    val dayOrder = listOf(2, 3, 4, 5, 6, 7, 1)
    val dayLabel = mapOf(1 to "S", 2 to "M", 3 to "T", 4 to "W", 5 to "T", 6 to "F", 7 to "S")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(r.pkg, 48.dp)
            Spacer(Modifier.width(14.dp))
            Text(r.label, fontFamily = FontFamily.Serif, fontSize = 30.sp)
        }

        SectionLabel("Pause before opening")
        SliderRow("Delay", r.delaySeconds, 0, 60, 1, { if (it == 0) "Off" else "${it}s" }) {
            r = r.copy(delaySeconds = it)
        }
        SwitchRow("Wait grows with each open (+5s)", r.progressiveDelay) { r = r.copy(progressiveDelay = it) }
        SwitchRow("Breathing animation", r.breathing) { r = r.copy(breathing = it) }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = r.message,
            onValueChange = { r = r.copy(message = it) },
            label = { Text("Message on the pause screen") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        ChipRow(SUGGESTED_MESSAGES, SUGGESTED_MESSAGES.indexOf(r.message)) { r = r.copy(message = SUGGESTED_MESSAGES[it]) }

        SectionLabel("Interrupt scrolling")
        SliderRow("Session length", r.sessionMinutes, 0, 30, 1, { if (it == 0) "Off" else "$it min" }) {
            r = r.copy(sessionMinutes = it)
        }
        SliderRow("Cooldown after a session", r.cooldownMinutes, 1, 120, 1, { "$it min" }) {
            r = r.copy(cooldownMinutes = it)
        }

        SectionLabel("Goals")
        SliderRow("Daily time limit", r.dailyLimitMinutes, 0, 300, 5, { if (it == 0) "Off" else "$it min" }) {
            r = r.copy(dailyLimitMinutes = it)
        }
        SwitchRow("Block when the limit is reached", r.blockAtLimit) { r = r.copy(blockAtLimit = it) }
        SliderRow("Daily opens limit", r.dailyOpensLimit, 0, 50, 1, { if (it == 0) "Off" else "$it opens" }) {
            r = r.copy(dailyOpensLimit = it)
        }
        SwitchRow("Block when opens are used up", r.blockAtOpensLimit) { r = r.copy(blockAtOpensLimit = it) }

        SectionLabel("Schedule")
        MutedText("Pauses and goals only apply on these days and between these times.")
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            dayOrder.forEach { d ->
                FilterChip(
                    selected = d in r.days,
                    onClick = {
                        val next = if (d in r.days) r.days - d else r.days + d
                        if (next.isNotEmpty()) r = r.copy(days = next)
                    },
                    label = { Text(dayLabel.getValue(d)) }
                )
            }
        }
        SliderRow("Active from", r.activeFromMin, 0, 1440, 15, { TimeUtil.fmt(it) }) {
            r = r.copy(activeFromMin = it)
        }
        SliderRow("Active until", r.activeToMin, 0, 1440, 15, { TimeUtil.fmt(it) }) {
            r = r.copy(activeToMin = it)
        }

        SectionLabel("Strict block")
        SwitchRow("Block completely, always", r.strictAlways) { r = r.copy(strictAlways = it) }
        SwitchRow("Block during a time window", r.strictFromMin >= 0) { on ->
            r = if (on) r.copy(strictFromMin = 22 * 60, strictToMin = 7 * 60)
            else r.copy(strictFromMin = -1, strictToMin = -1)
        }
        if (r.strictFromMin >= 0) {
            SliderRow("Blocked from", r.strictFromMin, 0, 1425, 15, { TimeUtil.fmt(it) }) {
                r = r.copy(strictFromMin = it)
            }
            SliderRow("Blocked until", r.strictToMin, 0, 1425, 15, { TimeUtil.fmt(it) }) {
                r = r.copy(strictToMin = it)
            }
        }
        Spacer(Modifier.height(8.dp))
        SwitchRow("Allow a 5-minute emergency override (breaks streak)", r.allowEmergency) {
            r = r.copy(allowEmergency = it)
        }

        Spacer(Modifier.height(28.dp))
        Button(onClick = { onSave(r.copy(enabled = true)) }, modifier = Modifier.fillMaxWidth()) { Text("Save") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
        if (existing) {
            TextButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) { Text("Remove this app") }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ============================================================ words & sites

@Composable
fun WordsScreen(store: Store) {
    var kws by remember { mutableStateOf(store.keywords()) }
    var sites by remember { mutableStateOf(store.sites()) }
    var word by remember { mutableStateOf("") }
    var scope by remember { mutableStateOf(Scope.PAGE) }
    var whole by remember { mutableStateOf(true) }
    var wordDur by remember { mutableIntStateOf(0) }
    var domain by remember { mutableStateOf("") }
    var siteDur by remember { mutableIntStateOf(0) }
    val now = System.currentTimeMillis()

    fun remaining(until: Long): String = when {
        until == 0L -> "Always"
        until <= now -> "Expired"
        else -> "${fmtDuration(until - now)} left"
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Title("Words & sites")
            MutedText("Block a word or a website for good, or just for a while.")
            SectionLabel("Block a word")
            OutlinedTextField(
                value = word,
                onValueChange = { word = it },
                label = { Text("Word or phrase") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            MutedText("Look for it in")
            Spacer(Modifier.height(4.dp))
            ChipRow(Scope.values().map { it.label }, scope.ordinal) { scope = Scope.values()[it] }
            Spacer(Modifier.height(8.dp))
            SwitchRow("Whole word only", whole) { whole = it }
            MutedText("Block for")
            Spacer(Modifier.height(4.dp))
            ChipRow(DURATIONS.map { it.first }, wordDur) { wordDur = it }
            Spacer(Modifier.height(10.dp))
            Button(
                enabled = word.isNotBlank(),
                onClick = {
                    val ms = DURATIONS[wordDur].second
                    val until = if (ms == 0L) 0L else System.currentTimeMillis() + ms
                    kws = kws + KeywordRule(word.trim(), scope, whole, until)
                    store.saveKeywords(kws)
                    word = ""
                }
            ) { Text("Add word") }
        }
        items(kws) { k ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(k.word)
                    MutedText("${k.scope.label} · ${if (k.wholeWord) "whole word" else "any match"} · ${remaining(k.untilMillis)}", 12)
                }
                TextButton(onClick = {
                    kws = kws - k
                    store.saveKeywords(kws)
                }) { Text("Remove") }
            }
        }

        item {
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            SectionLabel("Block a website")
            OutlinedTextField(
                value = domain,
                onValueChange = { domain = it },
                label = { Text("e.g. reddit.com") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            MutedText("Block for")
            Spacer(Modifier.height(4.dp))
            ChipRow(DURATIONS.map { it.first }, siteDur) { siteDur = it }
            Spacer(Modifier.height(10.dp))
            Button(
                enabled = SiteRule.normalize(domain).contains('.'),
                onClick = {
                    val ms = DURATIONS[siteDur].second
                    val until = if (ms == 0L) 0L else System.currentTimeMillis() + ms
                    sites = sites.filter { it.domain != SiteRule.normalize(domain) } +
                        SiteRule(SiteRule.normalize(domain), until)
                    store.saveSites(sites)
                    domain = ""
                }
            ) { Text("Add website") }
        }
        items(sites) { s ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.domain)
                    MutedText(remaining(s.untilMillis), 12)
                }
                TextButton(onClick = {
                    sites = sites - s
                    store.saveSites(sites)
                }) { Text("Remove") }
            }
        }
        item {
            Spacer(Modifier.height(12.dp))
            MutedText(
                "Websites and words are read from the address bar and page of Chrome, Samsung Internet, " +
                    "Firefox, Brave, Edge, Opera, Vivaldi and DuckDuckGo. “Any app” looks at text on screen in every app.",
                12
            )
        }
    }
}

// ============================================================ settings

@Composable
fun SettingsScreen(store: Store) {
    var pinInput by remember { mutableStateOf("") }
    var hasPin by remember { mutableStateOf(store.hasPin()) }
    var streakVersion by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Title("Settings")

        SectionLabel("Settings lock")
        MutedText(
            if (hasPin) "A PIN is set. TamilZen asks for it whenever you open the app."
            else "Set a PIN so you can't quietly loosen your own rules."
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = pinInput,
            onValueChange = { pinInput = it.filter(Char::isDigit).take(8) },
            label = { Text(if (hasPin) "New PIN (4–8 digits)" else "PIN (4–8 digits)") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = pinInput.length >= 4,
                onClick = {
                    store.setPin(pinInput)
                    pinInput = ""
                    hasPin = true
                }
            ) { Text(if (hasPin) "Change PIN" else "Set PIN") }
            if (hasPin) {
                OutlinedButton(onClick = {
                    store.setPin(null)
                    hasPin = false
                }) { Text("Remove PIN") }
            }
        }

        SectionLabel("Streak")
        key(streakVersion) { MutedText("Current streak: ${store.streak()} day(s). Overriding a block or passing a goal breaks the day.") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { store.resetStreak(); streakVersion++ }) { Text("Reset streak") }

        SectionLabel("How it works")
        MutedText(
            "1. Switch on Accessibility and Usage access on the Home tab.\n" +
                "2. Add apps on the Apps tab and set a pause, session, limit, schedule or strict block.\n" +
                "3. Add words and websites on the Words tab, forever or on a timer.\n" +
                "4. Use the Focus timer on Home to block everything on your list for a set time.\n\n" +
                "TamilZen has no internet permission. Your rules and usage never leave this phone."
        )
    }
}
